﻿package com.example.security.model;

public record RiskCheckRequest(String userId, String action) {}

