﻿package com.example.security.model;

public record RateLimitResponse(boolean allowed) {}

