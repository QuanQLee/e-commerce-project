﻿package com.example.security.model;

public record RiskCheckResponse(boolean allowed, String reason) {}

