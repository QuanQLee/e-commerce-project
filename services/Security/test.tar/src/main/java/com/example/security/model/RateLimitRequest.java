﻿package com.example.security.model;

public record RateLimitRequest(String userId, String action) {}

