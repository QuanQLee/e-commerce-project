﻿package com.example.security.model;

public record TokenResponse(String token) {}

